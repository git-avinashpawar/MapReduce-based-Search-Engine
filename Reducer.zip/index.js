/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

const fs = require("fs");
const { Storage } = require("@google-cloud/storage");

var rawdata = { map: [] };

function combine(map) {
  var main_dict = {};

  for (let i = 0; i < map.length; i++) {
    if (map[i].text in main_dict) {
      main_dict[map[i].text].push([map[i].document, map[i].count]);
    } else {
      main_dict[map[i].text] = [[map[i].document, map[i].count]];
    }
  }

  return main_dict;
}

module.exports.Reducer = async function Reducer(req, res) {

var files = req.query.files || req.body.files;
var range = req.query.range || req.body.range;
 range= new RegExp(range);
var filename = req.query.filename || req.body.filename;


  //function for sleep
  function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }
  // download files

  const bucketName = "ecc-a-data";

  // define the path and name of Google Cloud Storage object to download
  const srcFilename = files;

  // define the destination folder of downloaded object
  const destFilename = "/tmp/" + files;

  // create a client
  const storage = new Storage({
    keyFilename: "./avinash-pawar-fall2021-562a0957ff94.json",
  });

  // define the function for file download
  async function downloadFile() {
    // passing the options
    const options = {
      destination: destFilename,
    };

    // download object from Google Cloud Storage bucket
    await storage.bucket(bucketName).file(srcFilename).download(options);
  }

  // call the download function and be ready to catch errors
  downloadFile().catch(console.error);

  await sleep(5000);

  files = "/tmp/" + files;
  var list = JSON.parse(fs.readFileSync(files, "utf-8"));

  for (let j = 0; j < list.map.length; j++) {
    var s = list.map[j].text.charAt(0);
    if (range.test(s) == true) {
      rawdata.map.push({
        text: list.map[j].text,
        document: list.map[j].document,
        count: list.map[j].count,
      });
    }
  }

  await sleep(3000);

  var SeatWithCat = rawdata.map;

  var result = combine(SeatWithCat);

  var json = JSON.stringify(result);

  file1 = "/tmp/" + filename + ".json";
  fs.writeFile(file1, json, "utf8", function (error) {
    if (error) {
      console.log(error);
    }
  });

  // push file to cloud

  // Replace with your bucket name and filename.
  const bucketname = "ecc-a-data";

  async function uploadFile() {
    await storage.bucket(bucketname).upload("/tmp/" + filename + ".json");

    // Need to make the file public before you can access it.
    await storage
      .bucket(bucketname)
      .file(filename + ".json")
      .makePublic();
  }
  uploadFile().catch(console.error);
  //return filename
  ret = "https://storage.googleapis.com/ecc-a-data/" + filename + ".json";
  
  res.status(200).send(ret);
}

