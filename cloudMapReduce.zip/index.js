/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

var request = require("request");

//function for sleep
function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}


module.exports.cloudMapReduce = async function cloudMapReduce(req, res) {

var files = req.query.files || req.body.files;
res.set('Access-Control-Allow-Origin', '*');



  // files for mergemapper
  var MergeMapper = {
    files: [],
  };
  //call mapper
  for (i = 0; i < files.length; i++) {
    var mapper = {
      link: files[i].link,
      fname: files[i].fname,
    };
    MergeMapper.files.push("mapper-" + files[i].fname + ".json");
    request(
      {
        url: "https://us-central1-avinash-pawar-fall2021.cloudfunctions.net/Maper",
        method: "POST",
        json: true,
        body: mapper,
      },
      function (error, response, body) {
        console.log(response.body);
      }
    );
    await sleep(1000);
  }

  // call MergeMapper
  await sleep(15000);
  console.log(MergeMapper);
  request(
    {
      url: "https://us-central1-avinash-pawar-fall2021.cloudfunctions.net/MergeMaper",
      method: "POST",
      json: true,
      body: MergeMapper,
    },
    function (error, response, body) {
      console.log(response.body);
    }
  );

  //call reducer

  var reducer = [
    {
      files: "mapper.json",
      range: "^[a-d]+$",
      filename: "reducer-1",
    },
    {
      files: "mapper.json",
      range: "^[e-h]+$",
      filename: "reducer-2",
    },
    {
      files: "mapper.json",
      range: "^[i-m]+$",
      filename: "reducer-3",
    },
    {
      files: "mapper.json",
      range: "^[n-r]+$",
      filename: "reducer-4",
    },
    {
      files: "mapper.json",
      range: "^[s-z]+$",
      filename: "reducer-5",
    },
  ];
  await sleep(10000);
  var MergeReducer = {
    files: [],
  };

  for (i = 0; i < reducer.length; i++) {
    var redu = {
      files: reducer[i].files,
      range: reducer[i].range,
      filename: reducer[i].filename,
    };
    MergeReducer.files.push(reducer[i].filename + ".json");
    console.log(redu);
    request(
      {
        url: "https://us-central1-avinash-pawar-fall2021.cloudfunctions.net/Reducer",
        method: "POST",
        json: true,
        body: redu,
      },
      function (error, response, body) {
        console.log(response.body);
      }
    );
    await sleep(1000);
  }
  var ret="https://storage.googleapis.com/ecc-a-data/reducer-data.json";
  // call mergemapper
  console.log(MergeReducer);
  await sleep(10000);
  request(
    {
      url: "https://us-central1-avinash-pawar-fall2021.cloudfunctions.net/MergeReducer",
      method: "POST",
      json: true,
      body: MergeReducer,
    },
    function (error, response, body) {
      console.log(response.body);
      ret=response.body;
    }
  );
  
  res.status(200).send(ret);
}

