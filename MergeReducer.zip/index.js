/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */


const fs = require("fs");
const https = require("https");
const { Storage } = require("@google-cloud/storage");

var rawdata = {};

//function for sleep
  function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }



module.exports.MergeReducer = async function MergeReducer(req,res) {
  

var files=req.query.files ||req.body.files ;


  for (let i = 0; i < files.length; i++) {
    // define the Google Cloud Storage bucket name
    const bucketName = "ecc-a-data";

    // define the path and name of Google Cloud Storage object to download
    const srcFilename = files[i];

    // define the destination folder of downloaded object
    const destFilename = "/tmp/" + files[i];

    // create a client
    const storage = new Storage();

    // define the function for file download
    async function downloadFile() {
      // passing the options
      const options = {
        destination: destFilename,
      };

      // download object from Google Cloud Storage bucket
      await storage.bucket(bucketName).file(srcFilename).download(options);
    }

    // call the download function and be ready to catch errors
    downloadFile().catch(console.error);
  }
  await sleep(5000);
  for (let i = 0; i < files.length; i++) {
    var file = "/tmp/" + files[i];
    fs.readFile(file, "utf8", function (err, data) {
      if (err) {
        console.log("File read failed:", err);
        return;
      }
      //console.log(files[i]);
      const list = JSON.parse(data);

      for (var key of Object.keys(list)) {
            rawdata[key] = list[key];
        }
    });
  }
  await sleep(5000);
  var json = JSON.stringify(rawdata);
  //console.log(json);
  fs.writeFile("/tmp/reducer-data.json", json, "utf8", function (error) {
    if (error) {
      console.log(error);
    }
  });
  await sleep(5000);

  const storage = new Storage({
    keyFilename: "./avinash-pawar-fall2021-562a0957ff94.json",
  });
  // Replace with your bucket name and filename.
  const bucketname = "ecc-a-data";
  const filename = "reducer-data.json";

  async function uploadFile() {
    await storage.bucket(bucketname).upload("/tmp/" + filename);

    // Need to make the file public before you can access it.
    await storage.bucket(bucketname).file(filename).makePublic();
  }
  uploadFile().catch(console.error);
  var ret = "https://storage.googleapis.com/ecc-a-data/" + filename;

  res.status(200).send(ret);
}
