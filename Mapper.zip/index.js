/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */


const fs = require("fs");
const https = require("https");
const { Storage } = require("@google-cloud/storage");

var rawdata = { file: [] };

module.exports.Maper = async function Maper(req,res) {
  //function for sleep
  function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }

var link=req.query.link ||req.body.link ;
var fname=req.query.fname || req.body.fname;


  var file = "/tmp/" + fname + ".txt";

  const newfile = fs.createWriteStream(file);
  let request = https.get(link, function (response) {
    response.pipe(newfile);
  });

  // wait to download
  await sleep(5000);

  //mapper

  var string = fs.readFileSync(file).toString();

  string1 = string.toLowerCase();
  var freq = string1
    .replace(/[^a-zA-Z ]/g, " ")
    .split(/\s/)
    .reduce(
      (map, word) =>
        Object.assign(map, {
          [word]: map[word] ? map[word] + 1 : 1,
        }),
      {}
    );

  Object.keys(freq)
    .sort()
    .forEach(function (word) {
      //console.log(word);
      rawdata.file.push({ text: word, document: fname, count: freq[word] });
    });
  var json = JSON.stringify(rawdata);

  var out ="/tmp/mapper-" + fname + ".json";
  fs.writeFile(out, json, "utf8", function (error) {
    if (error) {
      console.log(error);
    }
  });

  await sleep(5000);

  // push file to cloud
  const storage = new Storage({
    keyFilename: "./avinash-pawar-fall2021-562a0957ff94.json",
  });
  // Replace with your bucket name and filename.
  const bucketname = "ecc-a-data";
  const filename = "mapper-"+fname+".json";

  async function uploadFile() {
    await storage.bucket(bucketname).upload("/tmp/" + filename);

    // Need to make the file public before you can access it.
    await storage.bucket(bucketname).file(filename).makePublic();
  }
  uploadFile().catch(console.error);
  //return filename
  var ret = "https://storage.googleapis.com/ecc-a-data/" + filename;

  
  res.status(200).send(ret);
}